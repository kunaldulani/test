package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Stock;
import com.cg.exception.StockTradingException;

@Repository
@Transactional
public class StockDaoImpl implements IStockDao 
{
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Stock> viewAll() throws StockTradingException
	{
		TypedQuery<Stock> query = entityManager.createQuery("from Stock", Stock.class);
		System.out.println(query.getResultList());
		return query.getResultList();		
	}

	@Override
	public Stock search(String stock) throws StockTradingException
	{
		Stock resultStock=entityManager.find(Stock.class, stock);
		return resultStock;
	}

}
