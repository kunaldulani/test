package com.cg.dao;

import com.cg.bean.Order;
import com.cg.exception.StockTradingException;

public interface IOrderDao
{
	public float[] buy(float quote, int quantity) throws StockTradingException;
	public float[] sell(float quote, int quantity) throws StockTradingException;
}
