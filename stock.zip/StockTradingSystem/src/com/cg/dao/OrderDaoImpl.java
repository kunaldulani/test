package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Order;
import com.cg.exception.StockTradingException;

@Repository
@Transactional
public class OrderDaoImpl implements IOrderDao 
{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public float[] buy(float quote, int quantity) throws StockTradingException {
		float[] result = {(float) (quote*0.05), quote*quantity};
		System.out.println(quote + " "+ quantity);
		System.out.println("DAO"+ result[0]+ " "+ result[1]);
		return result;
	}

	@Override
	public float[] sell(float quote, int quantity) throws StockTradingException {
		float[] result = {(float) (quote*0.01), quote*quantity};
		System.out.println("DAO"+ result);
		return result;
	}

}
