package com.cg.dao;

import java.util.List;

import com.cg.bean.Stock;
import com.cg.exception.StockTradingException;

public interface IStockDao
{
	List<Stock> viewAll() throws StockTradingException;
	Stock search(String stock) throws StockTradingException;
}
