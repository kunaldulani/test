package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Stock;
import com.cg.exception.StockTradingException;
import com.cg.service.IOrderService;
import com.cg.service.IStockService;
import com.cg.service.OrderServiceImpl;

@Controller
public class StockController 
{
	@Autowired
	IStockService stockService;
	IOrderService iOrderService = new OrderServiceImpl();	
	public IStockService getStockService() {
		return stockService;
	}

	public void setStockService(IStockService stockService) {
		this.stockService = stockService;
	}

	@RequestMapping("index")
	public ModelAndView viewAll()
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<Stock> list = stockService.viewAll();
			if (list.isEmpty()) {
				String msg = "There are no Stock to Display";
				mv.setViewName("myError");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("index");
				mv.addObject("list", list);
			}
			
		} catch (StockTradingException e) 
		{
			String msg = "Error Occured";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}
		return mv;
	}
	
	@RequestMapping("search")
	public ModelAndView search(@ModelAttribute("stock") Stock stock)
	{
		ModelAndView mv = new ModelAndView();

		Stock newStock = new Stock();
		try {
			newStock = stockService.search(stock.getStock());
		
		} catch (StockTradingException e) {
			String msg = "Stock Not Found";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		if (newStock != null) {
			mv.setViewName("order");
			mv.addObject("stock", newStock);
		} else {
			String msg = "Stock Not Found";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	//action.obj?operation=Buy&quantity=15&Order=Order
	@RequestMapping("action")
	public ModelAndView action(@RequestParam("quote") float quote, @RequestParam("operation") String operation,
			@RequestParam("quantity") int quantity)
	{
		float[] result= null;
		try {
			
			if(operation.equals("Buy"))
				result = iOrderService.buy(quote, quantity);
			else
				result = iOrderService.sell(quote, quantity);
			//System.out.println("Quote:"+stock.getQuote()+result[0] +" "+ result[1]);
		} catch (StockTradingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("orderSummary");
		//mv.addObject("stock", stock);
		mv.addObject("operation", operation);
		mv.addObject("quantity", quantity);
		mv.addObject("commission", result[0]);
		mv.addObject("totalPrice", result[1]);
		return mv;
	}
}