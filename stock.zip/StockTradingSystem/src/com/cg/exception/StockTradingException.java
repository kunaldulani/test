package com.cg.exception;

public class StockTradingException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -967325387072454581L;

	public StockTradingException(String message)
	{
		super(message);
	}
	
}
