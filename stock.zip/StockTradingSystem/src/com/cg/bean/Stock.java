package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stock_master")
public class Stock 
{
	@Id
	@Column(length = 20)
	private String stock;
	
	private float quote;

	public Stock()
	{
		super();
	}

	public Stock(String stock, float quote) 
	{
		super();
		this.stock = stock;
		this.quote = quote;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public float getQuote() {
		return quote;
	}

	public void setQuote(float quote) {
		this.quote = quote;
	}

	@Override
	public String toString() {
		return "Stock [stock=" + stock + ", quote=" + quote + "]";
	}
	
}
