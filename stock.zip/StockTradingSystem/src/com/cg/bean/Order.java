package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name ="order_master")
public class Order 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="stockSeq")
	@SequenceGenerator(name="stockSeq", sequenceName="stock_seq")
	private int orderId;
	
	@Column(name = "stock",length = 20)
	private String stock;
	
	@Column(name ="quote")
	private float quote;
	
	@Column(name="order_amount")
	private float orderAmount;
	
	@Column(name = "commission")
	private float commision;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int orderId, String stock, float quote, float orderAmount,
			float commision) {
		super();
		this.orderId = orderId;
		this.stock = stock;
		this.quote = quote;
		this.orderAmount = orderAmount;
		this.commision = commision;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public float getQuote() {
		return quote;
	}

	public void setQuote(float quote) {
		this.quote = quote;
	}

	public float getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(float orderAmount) {
		this.orderAmount = orderAmount;
	}

	public float getCommision() {
		return commision;
	}

	public void setCommision(float commision) {
		this.commision = commision;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", stock=" + stock + ", quote="
				+ quote + ", orderAmount=" + orderAmount + ", commision="
				+ commision + "]";
	}
	
	
	
}
