package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Order;
import com.cg.dao.IOrderDao;
import com.cg.dao.OrderDaoImpl;
import com.cg.exception.StockTradingException;

@Service
public class OrderServiceImpl implements IOrderService 
{
	@Autowired
	IOrderDao orderDao= new OrderDaoImpl();
	
	public IOrderDao getOrderDao() {
		return orderDao;
	}

	public void setOrderDao(IOrderDao orderDao) {
		this.orderDao = orderDao;
	}

	@Override
	public float[] buy(float quote, int quantity) throws StockTradingException {
		return orderDao.buy(quote, quantity);
	}

	@Override
	public float[] sell(float quote, int quantity) throws StockTradingException {
		return orderDao.sell(quote, quantity);
	}

	

}
