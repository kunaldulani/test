package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Stock;
import com.cg.dao.IStockDao;
import com.cg.dao.StockDaoImpl;
import com.cg.exception.StockTradingException;

@Service
public class StockServiceImpl implements IStockService 
{
	@Autowired
	IStockDao stockDao = new StockDaoImpl();
	
	@Override
	public List<Stock> viewAll() throws StockTradingException
	{
		return stockDao.viewAll();
	}

	public IStockDao getStockDao() {
		return stockDao;
	}

	public void setStockDao(IStockDao stockDao) {
		this.stockDao = stockDao;
	}

	@Override
	public Stock search(String stock) throws StockTradingException 
	{
		return stockDao.search(stock);
	}

}
