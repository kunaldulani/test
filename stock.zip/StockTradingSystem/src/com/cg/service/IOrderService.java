package com.cg.service;

import com.cg.bean.Order;
import com.cg.exception.StockTradingException;

public interface IOrderService 
{
	public float[] buy(float quote, int quantity) throws StockTradingException;
	public float[] sell(float quote, int quantity) throws StockTradingException;
}
