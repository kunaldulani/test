package com.cg.service;

import java.util.List;

import com.cg.bean.Stock;
import com.cg.exception.StockTradingException;

public interface IStockService 
{
	public List<Stock> viewAll() throws StockTradingException;
	public Stock search(String stock) throws StockTradingException;
}
