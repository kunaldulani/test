package com.test;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;


@Aspect
public class AccountAspect {
	
	
	@Before("execution(public void com.test.*.withdraw())")
	public void beforeAdvice()
	{
		System.out.println(" before advice called ");
	}
	
	/*@After("execution(public void com.test.SavingAccount.withdraw())")
	public void afterAdvice()
	{
		System.out.println(" after advice called ");
	}*/

}
